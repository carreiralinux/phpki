<?php
define(PHPKI_VERSION, "0.83");
?>
