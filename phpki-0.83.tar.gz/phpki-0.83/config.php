<?php
define('PHPKI_VERSION','0.83');
define('STORE_DIR','/var/www/phpki-store');
define('DEMO',FALSE);
define('BASE_URL','http://phpki.carreiralinux.com.br/');
?>